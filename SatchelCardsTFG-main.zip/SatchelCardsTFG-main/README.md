# SatchelCardsTFG

Proyecto TFG de Satchel

Hecho por:
  - Fernando Garcia Fernandez
  - Oday Ben Yachrak Fezzaga
  - Raul Albañil Guzman
  - Jose David Gomez Moreno
  - Ignacio Perez Sanchez
